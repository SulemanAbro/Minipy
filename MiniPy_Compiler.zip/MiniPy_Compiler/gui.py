"""Tkinter graphical interface for MiniPy.

This file only builds windows and shows results. All compiler work is done
by compiler.compile_source(); nothing here is hard-coded.
"""
from __future__ import annotations

import re
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from tkinter import font as tkfont
from typing import Optional

from ast_nodes import format_tree
from compiler import CompilationResult, compile_source

# ---- dark theme colours -----------------------------------------------------
BG = "#1b1d26"
PANEL = "#232634"
PANEL_ALT = "#2b2f40"
FG = "#e4e6ef"
MUTED = "#8b90a7"
ACCENT = "#5aa2ff"
OK_COLOR = "#5fd38d"
ERR_COLOR = "#ff6b7a"
WARN_COLOR = "#f0c35a"
SELECT_BG = "#3a4670"

EXAMPLES_DIR = Path(__file__).resolve().parent / "examples"

SYNTAX_COLORS = {
    "keyword": "#c792ea", "type": "#5aa2ff", "boolean": "#f78c6c",
    "number": "#f78c6c", "string": "#9ccc65", "comment": "#6b7190",
}
SYNTAX_PATTERNS = [
    ("keyword", r"\b(?:let|print|if|else|and|or|not)\b"),
    ("type", r"\b(?:int|float|string|bool)\b"),
    ("boolean", r"\b(?:true|false)\b"),
    ("number", r"\b\d+(?:\.\d+)?\b"),
    ("string", r'"[^"\n]*"?'),
    ("comment", r"//[^\n]*"),        # last = highest priority
]


def pick_font(root: tk.Misc, candidates, size: int, weight: str = "normal") -> tkfont.Font:
    available = set(tkfont.families(root))
    family = next((name for name in candidates if name in available), "TkFixedFont")
    return tkfont.Font(root=root, family=family, size=size, weight=weight)


class LineNumberedEditor(ttk.Frame):
    """A Text widget with a line-number gutter and simple syntax colours."""

    def __init__(self, master: tk.Misc, font: tkfont.Font) -> None:
        super().__init__(master)
        self._line_count = 0
        common = dict(font=font, wrap="none", borderwidth=0, highlightthickness=0, padx=8, pady=6)
        self.numbers = tk.Text(self, width=5, state="disabled", takefocus=0, cursor="arrow",
                               bg=PANEL_ALT, fg=MUTED, **common)
        self.text = tk.Text(self, undo=True, bg=PANEL, fg=FG, insertbackground=FG,
                            selectbackground=SELECT_BG, **common)
        self.vsb = ttk.Scrollbar(self, orient="vertical", command=self._yview)
        self.hsb = ttk.Scrollbar(self, orient="horizontal", command=self.text.xview)
        self.text.configure(yscrollcommand=self._on_text_scroll, xscrollcommand=self.hsb.set)
        self.numbers.tag_configure("right", justify="right")

        self.numbers.grid(row=0, column=0, sticky="ns")
        self.text.grid(row=0, column=1, sticky="nsew")
        self.vsb.grid(row=0, column=2, sticky="ns")
        self.hsb.grid(row=1, column=1, sticky="ew")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)

        for tag, colour in SYNTAX_COLORS.items():
            self.text.tag_configure(tag, foreground=colour)
        self.text.tag_configure("warning_line", background="#3d3822")
        self.text.tag_configure("error_line", background="#40242b")
        self.text.tag_configure("error_mark", foreground=ERR_COLOR, underline=True)
        self.text.tag_configure("warning_mark", foreground=WARN_COLOR, underline=True)

        self.text.bind("<<Modified>>", self._on_modified)
        self.text.bind("<Tab>", self._insert_spaces)
        self.numbers.bind("<MouseWheel>", lambda e: "break")
        self._refresh()

    # --- scrolling -----------------------------------------------------------
    def _yview(self, *args) -> None:
        self.text.yview(*args)
        self.numbers.yview(*args)

    def _on_text_scroll(self, first: str, last: str) -> None:
        self.vsb.set(first, last)
        self.numbers.yview_moveto(first)

    # --- content -------------------------------------------------------------
    def get_text(self) -> str:
        return self.text.get("1.0", "end-1c")

    def set_text(self, content: str) -> None:
        self.text.delete("1.0", "end")
        self.text.insert("1.0", content)
        self.text.edit_reset()

    def _insert_spaces(self, _event) -> str:
        self.text.insert("insert", "    ")
        return "break"

    def _on_modified(self, _event=None) -> None:
        if self.text.edit_modified():
            self._refresh()
            self.text.edit_modified(False)

    def _refresh(self) -> None:
        last = int(self.text.index("end-1c").split(".")[0])
        if last != self._line_count:
            self._line_count = last
            self.numbers.configure(state="normal")
            self.numbers.delete("1.0", "end")
            self.numbers.insert("1.0", "\n".join(str(n) for n in range(1, last + 1)), "right")
            self.numbers.configure(state="disabled")
            self.numbers.yview_moveto(self.text.yview()[0])
        self._colour_syntax()

    def _colour_syntax(self) -> None:
        content = self.get_text()
        for tag in SYNTAX_COLORS:
            self.text.tag_remove(tag, "1.0", "end")
        for tag, pattern in SYNTAX_PATTERNS:
            for match in re.finditer(pattern, content):
                self.text.tag_add(tag, f"1.0+{match.start()}c", f"1.0+{match.end()}c")

    # --- error marks ---------------------------------------------------------
    def clear_marks(self) -> None:
        for tag in ("error_line", "warning_line", "error_mark", "warning_mark"):
            self.text.tag_remove(tag, "1.0", "end")

    def mark(self, line: int, column: int, is_warning: bool) -> None:
        if line < 1 or line > self._line_count:
            return
        kind = "warning" if is_warning else "error"
        self.text.tag_add(f"{kind}_line", f"{line}.0", f"{line}.0 lineend+1c")
        start = f"{line}.{max(column - 1, 0)}"
        self.text.tag_add(f"{kind}_mark", start, f"{start} wordend" if column > 0 else start)
        self.text.tag_raise(f"{kind}_mark")

    def goto(self, line: int, column: int) -> None:
        self.text.focus_set()
        self.text.mark_set("insert", f"{max(line, 1)}.{max(column - 1, 0)}")
        self.text.see("insert")


class MiniPyApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        root.title("MiniPy Compiler")
        root.geometry("1150x820")
        root.minsize(900, 640)
        root.configure(bg=BG)
        self.ui_font = tkfont.Font(root=root, family="Segoe UI", size=10)
        self.mono_font = pick_font(root, ("Consolas", "Cascadia Mono", "Menlo", "DejaVu Sans Mono",
                                          "Courier New"), 11)
        self._current_path: Optional[Path] = None
        self._configure_style()
        self._build_header()
        self._build_toolbar()
        self._build_status_bar()          # packed at the bottom before the main area
        self._build_main_area()
        root.bind("<F5>", lambda _e: self.compile())
        root.bind("<Control-Return>", lambda _e: self.compile())
        root.bind("<Control-s>", lambda _e: self.save_source())
        root.bind("<Control-o>", lambda _e: self.open_file())
        self._set_indicator("Ready", MUTED)

    # ------------------------------------------------------------ styling
    def _configure_style(self) -> None:
        style = ttk.Style(self.root)
        style.theme_use("clam")
        style.configure(".", background=BG, foreground=FG, fieldbackground=PANEL, font=self.ui_font,
                        bordercolor=PANEL_ALT, lightcolor=PANEL_ALT, darkcolor=PANEL_ALT)
        style.configure("TFrame", background=BG)
        style.configure("TLabel", background=BG, foreground=FG)
        style.configure("Title.TLabel", font=("Segoe UI", 18, "bold"), foreground=ACCENT)
        style.configure("Sub.TLabel", foreground=MUTED)
        style.configure("Status.TLabel", background=PANEL_ALT, foreground=FG, padding=(10, 4))
        style.configure("TButton", background=PANEL_ALT, foreground=FG, padding=(14, 6), borderwidth=0)
        style.map("TButton", background=[("active", SELECT_BG)])
        style.configure("Accent.TButton", background=ACCENT, foreground="#0b0d12",
                        font=("Segoe UI", 10, "bold"))
        style.map("Accent.TButton", background=[("active", "#8bbcff")])
        style.configure("TMenubutton", background=PANEL_ALT, foreground=FG, padding=(14, 6), borderwidth=0)
        style.map("TMenubutton", background=[("active", SELECT_BG)])
        style.configure("TNotebook", background=BG, borderwidth=0)
        style.configure("TNotebook.Tab", background=PANEL, foreground=MUTED, padding=(16, 7))
        style.map("TNotebook.Tab", background=[("selected", PANEL_ALT)], foreground=[("selected", FG)])
        style.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=FG,
                        rowheight=26, borderwidth=0)
        style.configure("Treeview.Heading", background=PANEL_ALT, foreground=FG, relief="flat",
                        font=("Segoe UI", 10, "bold"))
        style.map("Treeview", background=[("selected", SELECT_BG)], foreground=[("selected", FG)])
        style.configure("TPanedwindow", background=BG)
        for name in ("Vertical.TScrollbar", "Horizontal.TScrollbar"):
            style.configure(name, background=SELECT_BG, troughcolor=PANEL, bordercolor=PANEL,
                            arrowcolor=FG, lightcolor=SELECT_BG, darkcolor=SELECT_BG, borderwidth=0)
            style.map(name, background=[("active", ACCENT), ("pressed", ACCENT)],
                      lightcolor=[("active", ACCENT)], darkcolor=[("active", ACCENT)])

    # ------------------------------------------------------------- layout
    def _build_header(self) -> None:
        header = ttk.Frame(self.root, padding=(16, 12, 16, 4))
        header.pack(fill="x")
        ttk.Label(header, text="MiniPy Compiler", style="Title.TLabel").pack(side="left")
        ttk.Label(header, style="Sub.TLabel", padding=(14, 8, 0, 0),
                  text="Lexer  •  Parser  •  AST  •  Semantic Analysis  •  Symbol Table  •  Three-Address Code"
                  ).pack(side="left")

    def _build_toolbar(self) -> None:
        bar = ttk.Frame(self.root, padding=(16, 6))
        bar.pack(fill="x")
        ttk.Button(bar, text="▶  Compile (F5)", style="Accent.TButton", command=self.compile).pack(side="left")
        ttk.Button(bar, text="Clear", command=self.clear).pack(side="left", padx=(8, 0))
        self.example_menu_button = ttk.Menubutton(bar, text="Load Example ▾")
        self.example_menu = tk.Menu(self.example_menu_button, tearoff=False, bg=PANEL_ALT, fg=FG,
                                    activebackground=SELECT_BG, activeforeground=FG, borderwidth=0)
        self._fill_example_menu()
        self.example_menu_button["menu"] = self.example_menu
        self.example_menu_button.pack(side="left", padx=(8, 0))
        ttk.Button(bar, text="Open…", command=self.open_file).pack(side="left", padx=(8, 0))
        ttk.Button(bar, text="Save Source", command=self.save_source).pack(side="left", padx=(8, 0))
        self.indicator = tk.Label(bar, text="", bg=BG, font=("Segoe UI", 11, "bold"))
        self.indicator.pack(side="right")

    def _build_status_bar(self) -> None:
        self.status_var = tk.StringVar(value="Ready.")
        ttk.Label(self.root, textvariable=self.status_var, style="Status.TLabel", anchor="w"
                  ).pack(side="bottom", fill="x")

    def _build_main_area(self) -> None:
        paned = ttk.PanedWindow(self.root, orient="vertical")
        paned.pack(fill="both", expand=True, padx=16, pady=(4, 10))
        self.editor = LineNumberedEditor(paned, self.mono_font)
        paned.add(self.editor, weight=3)

        self.notebook = ttk.Notebook(paned)
        paned.add(self.notebook, weight=3)

        self.token_tree = self._make_tree(
            "Tokens", [("#", 50), ("Type", 130), ("Lexeme", 220), ("Line", 70), ("Column", 80)])
        self.ast_text = self._make_text_tab("Abstract Syntax Tree")
        self.symbol_tree = self._make_tree(
            "Symbol Table", [("Name", 150), ("Type", 90), ("Scope", 160), ("Line", 70),
                             ("Initial Value", 150), ("Used", 70)])
        self.code_text = self._make_text_tab("Intermediate Code")
        self.error_tree = self._make_tree(
            "Errors and Warnings", [("Category", 130), ("Line", 60), ("Column", 70), ("Message", 700)])
        self.error_tree.tag_configure("error", foreground=ERR_COLOR)
        self.error_tree.tag_configure("warning", foreground=WARN_COLOR)
        self.error_tree.bind("<Double-1>", self._on_error_double_click)

    def _make_tree(self, title: str, columns) -> ttk.Treeview:
        frame = ttk.Frame(self.notebook)
        tree = ttk.Treeview(frame, columns=[c for c, _ in columns], show="headings", selectmode="browse")
        for name, width in columns:
            tree.heading(name, text=name)
            tree.column(name, width=width, anchor="w", stretch=(name == columns[-1][0]))
        scroll = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        tree.configure(yscrollcommand=scroll.set)
        tree.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.notebook.add(frame, text=title)
        return tree

    def _make_text_tab(self, title: str) -> tk.Text:
        frame = ttk.Frame(self.notebook)
        text = tk.Text(frame, font=self.mono_font, bg=PANEL, fg=FG, borderwidth=0, highlightthickness=0,
                       padx=12, pady=8, wrap="none", state="disabled", selectbackground=SELECT_BG)
        scroll = ttk.Scrollbar(frame, orient="vertical", command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.tag_configure("label", foreground=ACCENT)
        text.tag_configure("info", foreground=MUTED)
        text.pack(side="left", fill="both", expand=True)
        scroll.pack(side="right", fill="y")
        self.notebook.add(frame, text=title)
        return text

    # ------------------------------------------------------------ actions
    def compile(self) -> None:
        result = compile_source(self.editor.get_text())
        self._show_result(result)

    def clear(self) -> None:
        self.editor.set_text("")
        self.editor.clear_marks()
        self._current_path = None
        self._clear_outputs()
        self.notebook.tab(self.error_tree.master, text="Errors and Warnings")
        self._set_indicator("Ready", MUTED)
        self.status_var.set("Ready.")

    def _fill_example_menu(self) -> None:
        files = sorted(EXAMPLES_DIR.glob("*.mpy")) if EXAMPLES_DIR.is_dir() else []
        if not files:
            self.example_menu.add_command(label="(no example files found)", state="disabled")
        for path in files:
            self.example_menu.add_command(label=path.name, command=lambda p=path: self._load_path(p))

    def open_file(self) -> None:
        chosen = filedialog.askopenfilename(
            title="Open MiniPy source", filetypes=[("MiniPy source", "*.mpy"), ("All files", "*.*")])
        if chosen:
            self._load_path(Path(chosen))

    def _load_path(self, path: Path) -> None:
        try:
            content = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError) as error:
            messagebox.showerror("Cannot open file", f"{path}\n\n{error}")
            return
        self.editor.set_text(content)
        self.editor.clear_marks()
        self._current_path = path
        self._clear_outputs()
        self._set_indicator("Loaded", MUTED)
        self.status_var.set(f"Loaded {path.name}. Press Compile (F5).")

    def save_source(self) -> None:
        initial = self._current_path.name if self._current_path else "program.mpy"
        chosen = filedialog.asksaveasfilename(
            title="Save MiniPy source", defaultextension=".mpy", initialfile=initial,
            filetypes=[("MiniPy source", "*.mpy"), ("All files", "*.*")])
        if not chosen:
            return
        try:
            Path(chosen).write_text(self.editor.get_text(), encoding="utf-8")
        except OSError as error:
            messagebox.showerror("Cannot save file", str(error))
            return
        self._current_path = Path(chosen)
        self.status_var.set(f"Saved {chosen}")

    def _on_error_double_click(self, _event) -> None:
        selected = self.error_tree.selection()
        if selected:
            _category, line, column, _message = self.error_tree.item(selected[0], "values")
            self.editor.goto(int(line), int(column))

    # ----------------------------------------------------------- display
    def _set_indicator(self, text: str, colour: str) -> None:
        self.indicator.configure(text=f"●  {text}", fg=colour)

    @staticmethod
    def _fill_tree(tree: ttk.Treeview, rows, tags=None) -> None:
        tree.delete(*tree.get_children())
        for index, row in enumerate(rows):
            tree.insert("", "end", values=row, tags=(tags[index],) if tags else ())

    @staticmethod
    def _set_text(widget: tk.Text, content: str, tag: Optional[str] = None) -> None:
        widget.configure(state="normal")
        widget.delete("1.0", "end")
        widget.insert("1.0", content, tag or ())
        widget.configure(state="disabled")

    def _clear_outputs(self) -> None:
        for tree in (self.token_tree, self.symbol_tree, self.error_tree):
            tree.delete(*tree.get_children())
        for widget in (self.ast_text, self.code_text):
            self._set_text(widget, "")

    def _show_result(self, result: CompilationResult) -> None:
        self._clear_outputs()
        self.editor.clear_marks()

        self._fill_tree(self.token_tree, [
            (i, t.type, t.lexeme if t.type != "EOF" else "<EOF>", t.line, t.column)
            for i, t in enumerate(result.tokens, 1)])

        if result.program is not None:
            self._set_text(self.ast_text, format_tree(result.program))
        else:
            self._set_text(self.ast_text, "No AST: parsing did not succeed (see Errors and Warnings).", "info")

        if result.symbols is not None:
            self._fill_tree(self.symbol_tree, result.symbols.rows())

        if result.code:
            lines = [line if line.endswith(":") else "    " + line for line in result.code]
            self._set_text(self.code_text, "\n".join(lines))
        else:
            self._set_text(self.code_text, "No intermediate code: it is only generated for programs "
                                           "without errors.", "info")

        problems = result.errors.all
        self._fill_tree(self.error_tree,
                        [(e.category, e.line, e.column, e.message) for e in problems],
                        ["warning" if e.is_warning else "error" for e in problems])
        for problem in problems:
            self.editor.mark(problem.line, problem.column, problem.is_warning)
        count = len(problems)
        self.notebook.tab(self.error_tree.master,
                          text=f"Errors and Warnings ({count})" if count else "Errors and Warnings")

        error_count = len(result.errors.errors)
        warning_count = len(result.errors.warnings)
        phases = "  |  ".join(f"{name}: {status}" for name, status in result.phase_status.items())
        if result.success:
            self._set_indicator("Compilation successful", OK_COLOR)
            self.status_var.set(f"✔ Compiled successfully: {len(result.code)} intermediate instructions, "
                                f"{warning_count} warning(s).   {phases}")
            self.notebook.select(self.code_text.master)
        else:
            self._set_indicator(f"Compilation failed ({error_count} error{'s' if error_count != 1 else ''})",
                                ERR_COLOR)
            self.status_var.set(f"✘ Compilation failed: {error_count} error(s), {warning_count} warning(s).   "
                                f"{phases}")
            self.notebook.select(self.error_tree.master)


def launch(initial_file: Optional[str] = None) -> None:
    """Open the MiniPy window (blocks until it is closed)."""
    root = tk.Tk()
    app = MiniPyApp(root)
    if initial_file:
        app._load_path(Path(initial_file))
    root.mainloop()


if __name__ == "__main__":
    launch()
