# Suggested Viva Questions and Simple Answers

**1. What is a compiler? What does MiniPy actually do?**
A compiler translates a program from one language to another. MiniPy is the *front end*: it checks MiniPy code and translates it to three-address code (intermediate code). It does not create machine code.

**2. Name the phases of your compiler.**
Lexical analysis → syntax analysis (parsing) → AST → semantic analysis (with the symbol table) → intermediate code generation. Error handling works across all of them.

**3. What does the lexer do? Why a regular expression?**
It groups characters into tokens (keyword, identifier, number …). Token patterns are *regular languages*, which regular expressions describe exactly. One combined `re` pattern with named groups scans the text in one pass.

**4. What is a token? What does yours contain?**
A token is the smallest meaningful unit. Ours stores type, lexeme (the text), line and column.

**5. Why are keywords checked after matching an identifier pattern?**
`let` also looks like an identifier. We match any word first, then look it up in the keyword/type/boolean sets.

**6. What is a context-free grammar? Show a rule.**
A set of rules describing valid structure. Example: `var_decl = "let" IDENT ":" TYPE "=" expr ";"`.

**7. What is recursive-descent parsing?**
One function per grammar rule; functions call each other the same way the rules refer to each other. It is top-down and predictive (one token of lookahead).

**8. How did you get operator precedence?**
By layering the rules: `or` → `and` → `not` → comparison → `+ -` → `* /` → unary → primary. Rules lower in the chain bind tighter. `a + b * c` parses `b * c` first.

**9. How did you get left-associativity?**
Binary rules use a `while` loop, so `a - b - c` becomes `(a - b) - c`.

**10. What is an AST and how is it different from a parse tree?**
An AST keeps only meaningful nodes (no parentheses, semicolons or grammar-rule nodes). `(a + b) * c` has no "parenthesis" node; the shape of the tree already shows the order.

**11. How does the parser recover from errors?**
Panic-mode: after an error it skips tokens until a `;`, a `}` or a statement keyword, then continues, so several errors can be reported in one run.

**12. What does the semantic analyzer check that the parser cannot?**
Things grammar can't express: declared-before-use, duplicate declarations, type compatibility, boolean conditions, division by constant zero.

**13. Explain your type rules.**
No automatic conversion except `int → float`. `+ - *` on ints give int, with any float give float; `/` always gives float; `+` also joins strings; comparisons give bool (`< >` numeric only); `and/or/not` need bool.

**14. What is a symbol table? Why scopes?**
A table of declared names with type, scope, line and value. Each `if/else` block makes a new scope; an inner scope may shadow an outer name, but a name can't be declared twice in the same scope. Lookups go from the innermost scope outward.

**15. What is three-address code? Why use it?**
Each instruction has at most one operator and three addresses (`t2 = a + t1`). It is simple, close to machine code and easy to optimise or translate later.

**16. How is `a + b * c` translated?**
`t1 = b * c`, `t2 = a + t1`, `result = t2` — post-order traversal of the AST.

**17. How are `if` statements translated?**
Evaluate the condition into a temp, `ifFalse t goto L1`, then-code, (with `else`: `goto L2`, `L1:`, else-code, `L2:`), otherwise just `L1:` at the end.

**18. Why isn't code generated when there are errors?**
The compiler pipeline only runs a phase if the previous one succeeded; generating code from a wrong program would be meaningless.

**19. How do you know the GUI isn't faking results?**
The GUI only calls `compile_source()` and displays what it returns. Tests run the same functions with no GUI.

**20. What are the limitations of MiniPy?**
No loops, functions, arrays, input, or machine-code generation; no short-circuit evaluation in the generated code; variables with the same name in different scopes share one name in the TAC; lexical errors stop compilation before parsing.

**21. How would you extend it?**
Add `while`, functions, an optimiser (constant folding), a TAC interpreter, or a real back end (e.g. generating assembly or Python bytecode).

**22. What is the difference between a lexical, syntax and semantic error?**
Lexical: a bad character/token (`@`). Syntax: tokens in the wrong order (missing `;`). Semantic: grammar is fine but meaning is wrong (`let x: int = "hi";`).
