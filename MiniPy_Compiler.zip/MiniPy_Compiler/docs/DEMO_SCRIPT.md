# MiniPy — Presentation Demo Script (about 8–10 minutes)

**Before you start:** open a terminal in `MiniPy_Compiler`, run `python main.py`, and keep VS Code open on the project folder.

| Time | Who | What to say / do |
|------|-----|------------------|
| 0:00 | Student 1 | "MiniPy is a small compiler front-end. It reads a tiny language, checks it, and produces three-address code. It does **not** make machine code." Show the pipeline diagram from the README. |
| 1:00 | Student 1 | Describe the language: 4 types, `let`, assignment, `print`, `if/else`, arithmetic, comparison, `and/or/not`, `//` comments. Show the grammar in the README. |
| 2:00 | Student 2 | **Load Example → valid_program.mpy → Compile.** Point at the green status, the status bar listing all 4 phases as OK. |
| 2:45 | Student 1 | **Tokens tab:** "The lexer used one regular expression. Every token has type, lexeme, line and column. Comments and spaces are skipped." |
| 3:30 | Student 1 | **AST tab:** show line 4 `price * quantity + 5`. "`*` is deeper in the tree, so it runs first — that is operator precedence." |
| 4:15 | Student 2 | **Symbol Table tab:** names, types, scope (`global` and `if (line 12)`), declaration line, initial value, used flag. |
| 5:00 | Student 2 | **Intermediate Code tab:** show `t1 = price * quantity`, `t2 = t1 + 5`, `total = t2`, and `ifFalse … goto L1`, `goto L2`, labels. |
| 6:00 | Student 2 | **Load Example → invalid_program.mpy → Compile.** Red status, red underlines in the editor, Errors tab lists category, line, column, message. **Double-click an error** to jump to its line. Note: no intermediate code is generated. |
| 7:15 | Student 1 | **Load Example → syntax_error.mpy → Compile.** "The parser keeps going after an error (panic-mode recovery) so we see several syntax errors at once." |
| 8:00 | Student 1 | Type `let x: int = 5 @ 3;` live → lexical error for `@`. Clear, then compile empty editor → "program is empty". |
| 8:30 | Student 2 | In a terminal run `python -m unittest discover -s tests -v`. "62 tests, one per phase, no GUI needed — the GUI contains no compiler logic." |
| 9:30 | Both | Limitations & future work (README), then questions. |

**Live-typing ideas if the audience asks "what if…":**
`let a: int = 1; let b: float = a / 2; print(b);` (valid, `/` gives float) ·
`let s: string = "a" + 1;` (type error) ·
`if (1) { }` (condition not bool) ·
`print((1 + 2);` (unmatched parenthesis).
