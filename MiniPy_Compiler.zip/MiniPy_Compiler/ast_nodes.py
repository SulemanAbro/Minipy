"""Abstract Syntax Tree (AST) node classes for MiniPy.

Every node stores the line/column where it starts. Expression nodes also get
an `inferred_type` attribute filled in later by the semantic analyzer.
"""
from __future__ import annotations

from typing import List, Optional, Tuple


class Node:
    """Base class for all AST nodes."""

    def __init__(self, line: int = 0, column: int = 0) -> None:
        self.line = line
        self.column = column

    def label(self) -> str:
        return type(self).__name__

    def children(self) -> List[Tuple[str, "Node"]]:
        """Child nodes as (role, node) pairs, used for printing the tree."""
        return []

    def start(self) -> Tuple[int, int]:
        """Position where this construct begins in the source."""
        return (self.line, self.column)


class Expression(Node):
    """Base class for nodes that produce a value."""

    def __init__(self, line: int = 0, column: int = 0) -> None:
        super().__init__(line, column)
        self.inferred_type: Optional[str] = None  # set by SemanticAnalyzer

    def _type_suffix(self) -> str:
        return f"  [type: {self.inferred_type}]" if self.inferred_type else ""


class Literal(Expression):
    def __init__(self, value, type_name: str, raw: str, line: int, column: int) -> None:
        super().__init__(line, column)
        self.value = value
        self.type_name = type_name
        self.raw = raw

    def label(self) -> str:
        return f"Literal {self.raw} ({self.type_name})"


class Identifier(Expression):
    def __init__(self, name: str, line: int, column: int) -> None:
        super().__init__(line, column)
        self.name = name

    def label(self) -> str:
        return f"Identifier {self.name}{self._type_suffix()}"


class UnaryExpression(Expression):
    def __init__(self, operator: str, operand: Expression, line: int, column: int) -> None:
        super().__init__(line, column)
        self.operator = operator
        self.operand = operand

    def label(self) -> str:
        return f"UnaryExpression '{self.operator}'{self._type_suffix()}"

    def children(self):
        return [("operand", self.operand)]


class BinaryExpression(Expression):
    def __init__(self, operator: str, left: Expression, right: Expression, line: int, column: int) -> None:
        super().__init__(line, column)
        self.operator = operator
        self.left = left
        self.right = right

    def label(self) -> str:
        return f"BinaryExpression '{self.operator}'{self._type_suffix()}"

    def children(self):
        return [("left", self.left), ("right", self.right)]

    def start(self) -> Tuple[int, int]:
        return self.left.start()


class VariableDeclaration(Node):
    def __init__(self, name: str, type_name: str, initializer: Expression, line: int, column: int) -> None:
        super().__init__(line, column)
        self.name = name
        self.type_name = type_name
        self.initializer = initializer

    def label(self) -> str:
        return f"VariableDeclaration {self.name}: {self.type_name}"

    def children(self):
        return [("value", self.initializer)]


class Assignment(Node):
    def __init__(self, name: str, value: Expression, line: int, column: int) -> None:
        super().__init__(line, column)
        self.name = name
        self.value = value

    def label(self) -> str:
        return f"Assignment {self.name}"

    def children(self):
        return [("value", self.value)]


class PrintStatement(Node):
    def __init__(self, expression: Expression, line: int, column: int) -> None:
        super().__init__(line, column)
        self.expression = expression

    def children(self):
        return [("value", self.expression)]


class Block(Node):
    def __init__(self, statements: List[Node], line: int, column: int) -> None:
        super().__init__(line, column)
        self.statements = statements

    def children(self):
        return [("", s) for s in self.statements]


class IfStatement(Node):
    def __init__(self, condition: Expression, then_block: Block, else_block: Optional[Block],
                 line: int, column: int) -> None:
        super().__init__(line, column)
        self.condition = condition
        self.then_block = then_block
        self.else_block = else_block

    def children(self):
        kids = [("condition", self.condition), ("then", self.then_block)]
        if self.else_block is not None:
            kids.append(("else", self.else_block))
        return kids


class Program(Node):
    def __init__(self, statements: List[Node], line: int = 1, column: int = 1) -> None:
        super().__init__(line, column)
        self.statements = statements

    def children(self):
        return [("", s) for s in self.statements]


def format_tree(root: Node) -> str:
    """Return a readable multi-line text drawing of the tree."""
    lines = [root.label()]
    _walk(root, "", lines)
    return "\n".join(lines)


def _walk(node: Node, prefix: str, lines: List[str]) -> None:
    kids = node.children()
    for index, (role, child) in enumerate(kids):
        is_last = index == len(kids) - 1
        branch = "└── " if is_last else "├── "
        text = f"{role}: {child.label()}" if role else child.label()
        lines.append(prefix + branch + text)
        _walk(child, prefix + ("    " if is_last else "│   "), lines)
