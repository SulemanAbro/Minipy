"""Error collection and reporting shared by every compiler phase.

Each phase (lexer, parser, semantic analyzer) receives one ErrorHandler and
reports problems to it instead of crashing. The GUI and the tests read the
collected errors afterwards.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List

LEXICAL = "Lexical Error"
SYNTAX = "Syntax Error"
SEMANTIC = "Semantic Error"
WARNING = "Warning"


@dataclass(frozen=True)
class CompilerError:
    """One reported problem with its category and source location."""

    category: str
    message: str
    line: int = 0
    column: int = 0

    @property
    def is_warning(self) -> bool:
        return self.category == WARNING

    def __str__(self) -> str:
        if self.line > 0 and self.column > 0:
            where = f" at line {self.line}, column {self.column}"
        elif self.line > 0:
            where = f" at line {self.line}"
        else:
            where = ""
        return f"{self.category}{where}: {self.message}"


class ErrorHandler:
    """Collects errors and warnings produced during one compilation."""

    def __init__(self) -> None:
        self._items: List[CompilerError] = []

    def report(self, category: str, message: str, line: int = 0, column: int = 0) -> None:
        self._items.append(CompilerError(category, message, line, column))

    def lexical(self, message: str, line: int = 0, column: int = 0) -> None:
        self.report(LEXICAL, message, line, column)

    def syntax(self, message: str, line: int = 0, column: int = 0) -> None:
        self.report(SYNTAX, message, line, column)

    def semantic(self, message: str, line: int = 0, column: int = 0) -> None:
        self.report(SEMANTIC, message, line, column)

    def warning(self, message: str, line: int = 0, column: int = 0) -> None:
        self.report(WARNING, message, line, column)

    @property
    def errors(self) -> List[CompilerError]:
        """Real errors only (warnings are excluded)."""
        return [e for e in self._items if not e.is_warning]

    @property
    def warnings(self) -> List[CompilerError]:
        return [e for e in self._items if e.is_warning]

    @property
    def all(self) -> List[CompilerError]:
        """Errors and warnings sorted by position in the source."""
        return sorted(self._items, key=lambda e: (e.line, e.column))

    def has_errors(self) -> bool:
        return bool(self.errors)

    def has_category(self, category: str) -> bool:
        return any(e.category == category for e in self._items)

    def clear(self) -> None:
        self._items.clear()
