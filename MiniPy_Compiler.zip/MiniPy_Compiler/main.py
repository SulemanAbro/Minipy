"""MiniPy compiler entry point.

    python main.py                       open the GUI
    python main.py program.mpy           open the GUI with a file loaded
    python main.py --cli program.mpy     compile in the terminal (no GUI)
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from ast_nodes import format_tree
from compiler import compile_source


def run_cli(path: str) -> int:
    """Compile a file and print the result of each phase. Returns an exit code."""
    source = Path(path).read_text(encoding="utf-8")
    result = compile_source(source)

    print("=== TOKENS ===")
    for token in result.tokens:
        print(f"{token.line:>3}:{token.column:<3} {token.type:<10} {token.lexeme!r}")
    print("\n=== ABSTRACT SYNTAX TREE ===")
    print(format_tree(result.program) if result.program else "(not available - parsing failed)")
    print("\n=== SYMBOL TABLE ===")
    if result.symbols:
        print(f"{'Name':<12}{'Type':<8}{'Scope':<16}{'Line':<6}{'Initial':<10}Used")
        for name, type_name, scope, line, value, used in result.symbols.rows():
            print(f"{name:<12}{type_name:<8}{scope:<16}{line:<6}{value:<10}{used}")
    else:
        print("(not available - semantic analysis did not run)")
    print("\n=== INTERMEDIATE CODE (THREE-ADDRESS CODE) ===")
    print("\n".join(result.code) if result.code else "(not generated - the program has errors)")
    print("\n=== ERRORS AND WARNINGS ===")
    if result.errors.all:
        for error in result.errors.all:
            print(error)
    else:
        print("None")
    print("\nResult:", "SUCCESS" if result.success else "FAILED")
    return 0 if result.success else 1


def main(argv=None) -> int:
    arg_parser = argparse.ArgumentParser(description="MiniPy - a mini compiler with a Tkinter GUI.")
    arg_parser.add_argument("file", nargs="?", help="MiniPy source file (.mpy)")
    arg_parser.add_argument("--cli", action="store_true", help="compile in the terminal without the GUI")
    args = arg_parser.parse_args(argv)

    if args.cli:
        if not args.file:
            arg_parser.error("--cli needs a source file")
        return run_cli(args.file)

    from gui import launch   # imported late so --cli works even without Tkinter
    launch(args.file)
    return 0


if __name__ == "__main__":
    sys.exit(main())
