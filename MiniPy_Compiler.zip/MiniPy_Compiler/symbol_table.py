"""Symbol table with nested scopes for MiniPy."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple


@dataclass
class Symbol:
    """Information stored about one declared variable."""

    name: str
    type_name: str
    scope: str
    line: int
    column: int
    value: object = None   # initial value, only when the initializer is a literal
    used: bool = False     # becomes True once the variable is read

    def display_value(self) -> str:
        if self.value is None:
            return "-"
        if isinstance(self.value, bool):
            return "true" if self.value else "false"
        if isinstance(self.value, str):
            return f'"{self.value}"'
        return str(self.value)


class SymbolTable:
    """A stack of scopes. The global scope is always at the bottom."""

    GLOBAL = "global"

    def __init__(self) -> None:
        self._scopes: List[Dict[str, Symbol]] = [{}]
        self._scope_names: List[str] = [self.GLOBAL]
        self._history: List[Symbol] = []   # every symbol ever declared, in order

    @property
    def current_scope_name(self) -> str:
        return self._scope_names[-1]

    def enter_scope(self, name: str) -> None:
        self._scopes.append({})
        self._scope_names.append(name)

    def exit_scope(self) -> None:
        if len(self._scopes) == 1:
            raise RuntimeError("Cannot exit the global scope.")
        self._scopes.pop()
        self._scope_names.pop()

    def declare(self, name: str, type_name: str, line: int, column: int,
                value: object = None) -> Optional[Symbol]:
        """Add a symbol to the current scope.

        Returns None (and changes nothing) if the name already exists in the
        current scope, so a duplicate never overwrites the original.
        """
        if name in self._scopes[-1]:
            return None
        symbol = Symbol(name, type_name, self.current_scope_name, line, column, value)
        self._scopes[-1][name] = symbol
        self._history.append(symbol)
        return symbol

    def lookup(self, name: str) -> Optional[Symbol]:
        """Find a symbol searching from the innermost scope outwards."""
        for scope in reversed(self._scopes):
            if name in scope:
                return scope[name]
        return None

    def lookup_current_scope(self, name: str) -> Optional[Symbol]:
        return self._scopes[-1].get(name)

    def current_symbols(self) -> List[Symbol]:
        return list(self._scopes[-1].values())

    def all_symbols(self) -> List[Symbol]:
        """Every declared symbol (including ones whose scope has ended)."""
        return list(self._history)

    def rows(self) -> List[Tuple[str, str, str, int, str, str]]:
        """Rows for display: name, type, scope, line, initial value, used."""
        return [(s.name, s.type_name, s.scope, s.line, s.display_value(), "yes" if s.used else "no")
                for s in self._history]
