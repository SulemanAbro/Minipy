"""Semantic analyzer for MiniPy: scope and type checking on the AST.

TYPE RULES
  * Types: int, float, string, bool. There are no implicit conversions,
    except that an int value may be stored in a float variable (widening).
  * + - *  : int,int -> int | any float involved -> float.
             '+' also joins two strings (string + string -> string).
  * /      : numeric operands, the result is ALWAYS float (like Python 3).
             Dividing by the literal constant 0 is an error.
  * == !=  : both numeric (int/float mix allowed), or both of the same type -> bool.
  * < > <= >= : numeric operands only -> bool.
  * and or : bool operands only -> bool.      not : bool operand -> bool.
  * unary - : numeric operand, same type.
  * Conditions of 'if' must be bool.
SCOPES
  * Global scope plus one new scope per if/else block. A name may be
    re-declared in an inner block (shadowing) but not twice in one scope.
"""
from __future__ import annotations

from typing import List, Optional

from ast_nodes import (Assignment, BinaryExpression, Block, Expression, Identifier, IfStatement,
                       Literal, Node, PrintStatement, Program, UnaryExpression, VariableDeclaration)
from error_handler import ErrorHandler
from symbol_table import Symbol, SymbolTable

NUMERIC = ("int", "float")


def is_assignable(target: str, source: str) -> bool:
    """Can a value of type `source` be stored in a variable of type `target`?"""
    return target == source or (target == "float" and source == "int")


class SemanticAnalyzer:
    def __init__(self, errors: ErrorHandler) -> None:
        self.errors = errors
        self.symbols = SymbolTable()

    def analyze(self, program: Program) -> SymbolTable:
        """Check the whole program and return the filled symbol table."""
        self._statements(program.statements)
        self._warn_unused(self.symbols.current_symbols())
        return self.symbols

    # ------------------------------------------------------------ statements
    def _statements(self, statements: List[Node]) -> None:
        for statement in statements:
            self._statement(statement)

    def _statement(self, node: Node) -> None:
        if isinstance(node, VariableDeclaration):
            self._declaration(node)
        elif isinstance(node, Assignment):
            self._assignment(node)
        elif isinstance(node, PrintStatement):
            self._expression(node.expression)
        elif isinstance(node, IfStatement):
            self._if(node)
        elif isinstance(node, Block):
            self._block(node, f"block (line {node.line})")
        else:
            raise TypeError(f"Unknown statement node: {type(node).__name__}")

    def _declaration(self, node: VariableDeclaration) -> None:
        # Check the initializer first so that "let x: int = x;" is caught.
        value_type = self._expression(node.initializer)
        compatible = value_type is None or is_assignable(node.type_name, value_type)
        constant = None
        if isinstance(node.initializer, Literal) and compatible:
            constant = node.initializer.value
            if node.type_name == "float" and node.initializer.type_name == "int":
                constant = float(constant)
        symbol = self.symbols.declare(node.name, node.type_name, node.line, node.column, constant)
        if symbol is None:
            first = self.symbols.lookup_current_scope(node.name)
            self.errors.semantic(f"Variable '{node.name}' is already declared in this scope "
                                 f"(first declared at line {first.line}).", node.line, node.column)
        if not compatible:
            self._report_mismatch(node.type_name, value_type, node.name, node.initializer)

    def _assignment(self, node: Assignment) -> None:
        value_type = self._expression(node.value)
        symbol = self.symbols.lookup(node.name)
        if symbol is None:
            self.errors.semantic(f"Cannot assign to '{node.name}' because it was never declared. "
                                 f"Declare it first: let {node.name}: <type> = <value>;",
                                 node.line, node.column)
            return
        if value_type is not None and not is_assignable(symbol.type_name, value_type):
            self._report_mismatch(symbol.type_name, value_type, node.name, node.value)

    def _report_mismatch(self, target: str, source: str, name: str, expr: Expression) -> None:
        hint = ""
        if target == "int" and source == "float":
            hint = " MiniPy does not convert floats to int automatically (note: '/' always gives a float)."
        line, column = expr.start()
        article = "an" if source == "int" else "a"
        self.errors.semantic(f"Type mismatch: cannot store {article} {source} value in {target} "
                             f"variable '{name}'.{hint}", line, column)

    def _if(self, node: IfStatement) -> None:
        condition_type = self._expression(node.condition)
        if condition_type is not None and condition_type != "bool":
            line, column = node.condition.start()
            self.errors.semantic(f"The condition of 'if' must be bool, but it is {condition_type}. "
                                 "Hint: use a comparison such as x > 0.", line, column)
        self._block(node.then_block, f"if (line {node.line})")
        if node.else_block is not None:
            self._block(node.else_block, f"else (line {node.else_block.line})")

    def _block(self, block: Block, scope_name: str) -> None:
        self.symbols.enter_scope(scope_name)
        self._statements(block.statements)
        self._warn_unused(self.symbols.current_symbols())
        self.symbols.exit_scope()

    def _warn_unused(self, symbols: List[Symbol]) -> None:
        for symbol in symbols:
            if not symbol.used:
                self.errors.warning(f"Variable '{symbol.name}' is declared but never used.",
                                    symbol.line, symbol.column)

    # ----------------------------------------------------------- expressions
    def _expression(self, node: Expression) -> Optional[str]:
        """Return the type of the expression, or None if it could not be determined."""
        result = self._compute_type(node)
        node.inferred_type = result
        return result

    def _compute_type(self, node: Expression) -> Optional[str]:
        if isinstance(node, Literal):
            return node.type_name
        if isinstance(node, Identifier):
            symbol = self.symbols.lookup(node.name)
            if symbol is None:
                self.errors.semantic(f"Variable '{node.name}' is used but was never declared.",
                                     node.line, node.column)
                return None
            symbol.used = True
            return symbol.type_name
        if isinstance(node, UnaryExpression):
            return self._unary(node)
        if isinstance(node, BinaryExpression):
            return self._binary(node)
        raise TypeError(f"Unknown expression node: {type(node).__name__}")

    def _unary(self, node: UnaryExpression) -> Optional[str]:
        operand = self._expression(node.operand)
        if node.operator == "not":
            if operand is None or operand == "bool":
                return "bool"
            self.errors.semantic(f"Operator 'not' needs a bool operand, but got {operand}.",
                                 node.line, node.column)
            return "bool"
        if operand is None or operand in NUMERIC:   # unary minus
            return operand
        self.errors.semantic(f"Operator '-' needs a numeric operand, but got {operand}.",
                             node.line, node.column)
        return None

    def _binary(self, node: BinaryExpression) -> Optional[str]:
        op = node.operator
        left = self._expression(node.left)
        right = self._expression(node.right)
        if op == "/" and isinstance(node.right, Literal) and node.right.type_name in NUMERIC \
                and node.right.value == 0:
            self.errors.semantic("Division by zero: the right side of '/' is the constant 0.",
                                 node.right.line, node.right.column)
        is_boolean_result = op in ("==", "!=", "<", ">", "<=", ">=", "and", "or")
        if left is None or right is None:
            return "bool" if is_boolean_result else None   # an error was already reported
        both_numeric = left in NUMERIC and right in NUMERIC
        promoted = "float" if "float" in (left, right) else "int"

        if op == "+":
            if both_numeric:
                return promoted
            if left == right == "string":
                return "string"
        elif op in ("-", "*"):
            if both_numeric:
                return promoted
        elif op == "/":
            if both_numeric:
                return "float"
        elif op in ("==", "!="):
            if both_numeric or left == right:
                return "bool"
        elif op in ("<", ">", "<=", ">="):
            if both_numeric:
                return "bool"
        elif op in ("and", "or"):
            if left == right == "bool":
                return "bool"
        else:
            raise ValueError(f"Unknown binary operator: {op}")

        self.errors.semantic(self._operator_message(op, left, right), node.line, node.column)
        return "bool" if is_boolean_result else None

    @staticmethod
    def _operator_message(op: str, left: str, right: str) -> str:
        if op in ("and", "or"):
            return f"Operator '{op}' needs bool operands, but got {left} and {right}."
        if op in ("==", "!="):
            return f"Cannot compare {left} with {right} using '{op}'."
        if op in ("<", ">", "<=", ">="):
            return f"Operator '{op}' needs numeric operands, but got {left} and {right}."
        return (f"Operator '{op}' cannot be applied to {left} and {right}. "
                "MiniPy never converts types automatically.")
