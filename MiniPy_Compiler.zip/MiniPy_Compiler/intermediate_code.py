"""Three-address code (TAC) generator for MiniPy.

Walks a semantically valid AST and produces a list of text instructions:

    t1 = b * c          arithmetic / comparison / logic with temporaries
    result = t2         copy into a variable
    print result        output
    ifFalse t1 goto L1  conditional jump
    goto L2             unconditional jump
    L1:                 label

Operator precedence is already encoded in the tree shape, so the generator
simply emits the children before the parent (post-order).
This is intermediate code only - not machine code.
"""
from __future__ import annotations

from typing import List

from ast_nodes import (Assignment, BinaryExpression, Block, Expression, Identifier, IfStatement,
                       Literal, Node, PrintStatement, Program, UnaryExpression, VariableDeclaration)


class CodeGenerator:
    def __init__(self) -> None:
        self.instructions: List[str] = []
        self._temp_count = 0
        self._label_count = 0

    def generate(self, program: Program) -> List[str]:
        """Generate TAC for a program. Call only after semantic analysis succeeded."""
        self.instructions = []
        self._temp_count = 0
        self._label_count = 0
        for statement in program.statements:
            self._statement(statement)
        return self.instructions

    # ---------------------------------------------------------------- helpers
    def _emit(self, text: str) -> None:
        self.instructions.append(text)

    def _new_temp(self) -> str:
        self._temp_count += 1
        return f"t{self._temp_count}"

    def _new_label(self) -> str:
        self._label_count += 1
        return f"L{self._label_count}"

    # ------------------------------------------------------------- statements
    def _statement(self, node: Node) -> None:
        if isinstance(node, (VariableDeclaration, Assignment)):
            value = self._expression(node.initializer if isinstance(node, VariableDeclaration) else node.value)
            self._emit(f"{node.name} = {value}")
        elif isinstance(node, PrintStatement):
            self._emit(f"print {self._expression(node.expression)}")
        elif isinstance(node, IfStatement):
            self._if(node)
        elif isinstance(node, Block):
            for statement in node.statements:
                self._statement(statement)
        else:
            raise TypeError(f"Unknown statement node: {type(node).__name__}")

    def _if(self, node: IfStatement) -> None:
        condition = self._expression(node.condition)
        false_label = self._new_label()
        self._emit(f"ifFalse {condition} goto {false_label}")
        self._statement(node.then_block)
        if node.else_block is None:
            self._emit(f"{false_label}:")
            return
        end_label = self._new_label()
        self._emit(f"goto {end_label}")
        self._emit(f"{false_label}:")
        self._statement(node.else_block)
        self._emit(f"{end_label}:")

    # ------------------------------------------------------------ expressions
    def _expression(self, node: Expression) -> str:
        """Emit code for the expression and return the name that holds its value."""
        if isinstance(node, Literal):
            return node.raw
        if isinstance(node, Identifier):
            return node.name
        if isinstance(node, UnaryExpression):
            operand = self._expression(node.operand)
            temp = self._new_temp()
            self._emit(f"{temp} = -{operand}" if node.operator == "-" else f"{temp} = not {operand}")
            return temp
        if isinstance(node, BinaryExpression):
            left = self._expression(node.left)
            right = self._expression(node.right)
            temp = self._new_temp()
            self._emit(f"{temp} = {left} {node.operator} {right}")
            return temp
        raise TypeError(f"Unknown expression node: {type(node).__name__}")
