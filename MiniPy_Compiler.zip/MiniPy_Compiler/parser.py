"""Recursive-descent parser for MiniPy.

Grammar (EBNF) - one method below per rule:

    program     = { statement } EOF
    statement   = var_decl | assignment | print_stmt | if_stmt
    var_decl    = "let" IDENT ":" TYPE "=" expr ";"
    assignment  = IDENT "=" expr ";"
    print_stmt  = "print" "(" expr ")" ";"
    if_stmt     = "if" "(" expr ")" block [ "else" ( block | if_stmt ) ]
    block       = "{" { statement } "}"

    expr        = or_expr
    or_expr     = and_expr { "or" and_expr }
    and_expr    = not_expr { "and" not_expr }
    not_expr    = "not" not_expr | comparison
    comparison  = term { ("==" | "!=" | "<" | ">" | "<=" | ">=") term }
    term        = factor { ("+" | "-") factor }
    factor      = unary { ("*" | "/") unary }
    unary       = "-" unary | primary
    primary     = NUMBER | STRING | BOOLEAN | IDENT | "(" expr ")"

Each rule sits one level below the previous one, which gives the correct
precedence (lowest first: or, and, not, comparison, + -, * /, unary minus).
Binary operators are left-associative because they are parsed in loops.

After a syntax error the parser skips to a safe point (panic-mode recovery)
so it can report more than one error per run.
"""
from __future__ import annotations

from typing import List

from ast_nodes import (Assignment, BinaryExpression, Block, Expression, Identifier,
                       IfStatement, Literal, PrintStatement, Program, UnaryExpression,
                       VariableDeclaration, Node)
from error_handler import ErrorHandler
from lexer import Token

COMPARISON_TOKENS = ("EQ", "NEQ", "LT", "GT", "LE", "GE")
STATEMENT_KEYWORDS = ("let", "print", "if")


class ParseError(Exception):
    """Raised internally to unwind to the nearest recovery point."""

    def __init__(self, message: str, line: int, column: int) -> None:
        super().__init__(message)
        self.message = message
        self.line = line
        self.column = column


class Parser:
    def __init__(self, tokens: List[Token], errors: ErrorHandler) -> None:
        self.tokens = tokens
        self.errors = errors
        self.pos = 0

    # ------------------------------------------------------------ entry point
    def parse(self) -> Program:
        """Parse the whole token list. Syntax errors go to the ErrorHandler."""
        statements = self._statement_list(in_block=False)
        if not statements and not self.errors.has_errors():
            self.errors.syntax("The program is empty: write at least one statement.", 1, 1)
        return Program(statements, 1, 1)

    # ------------------------------------------------------- token utilities
    def _peek(self) -> Token:
        return self.tokens[self.pos]

    def _previous(self) -> Token:
        return self.tokens[self.pos - 1]

    def _at_end(self) -> bool:
        return self._peek().type == "EOF"

    def _advance(self) -> Token:
        token = self._peek()
        if not self._at_end():
            self.pos += 1
        return token

    def _check(self, token_type: str) -> bool:
        return self._peek().type == token_type

    def _check_keyword(self, word: str) -> bool:
        token = self._peek()
        return token.type == "KEYWORD" and token.lexeme == word

    def _match(self, *token_types: str) -> bool:
        if self._peek().type in token_types:
            self._advance()
            return True
        return False

    @staticmethod
    def _describe(token: Token) -> str:
        return "end of file" if token.type == "EOF" else f"'{token.lexeme}'"

    def _error(self, message: str, after_previous: bool = False) -> ParseError:
        """Build an error at the current token, or just after the previous one."""
        if after_previous and self.pos > 0:
            prev = self._previous()
            return ParseError(message, prev.line, prev.column + len(prev.lexeme))
        token = self._peek()
        return ParseError(message, token.line, token.column)

    def _expect(self, token_type: str, message: str, after_previous: bool = False) -> Token:
        if self._check(token_type):
            return self._advance()
        raise self._error(message, after_previous)

    def _expect_semicolon(self, what: str) -> None:
        if self._check("SEMICOLON"):
            self._advance()
        elif self._check("RPAREN"):
            raise self._error("Unmatched ')': there is no matching '(' before it.")
        else:
            raise self._error(f"Expected ';' after {what}.", after_previous=True)

    # -------------------------------------------------------- error recovery
    def _synchronize(self) -> None:
        """Skip tokens until a likely statement boundary."""
        while not self._at_end():
            if self.pos > 0 and self._previous().type == "SEMICOLON":
                return
            token = self._peek()
            if token.type == "RBRACE" or (token.type == "KEYWORD" and token.lexeme in STATEMENT_KEYWORDS):
                return
            self._advance()

    # ------------------------------------------------------------ statements
    def _statement_list(self, in_block: bool) -> List[Node]:
        statements: List[Node] = []
        while not self._at_end():
            if self._check("RBRACE"):
                if in_block:
                    break
                token = self._advance()
                self.errors.syntax("Unmatched '}': there is no open block to close.", token.line, token.column)
                continue
            start = self.pos
            try:
                statements.append(self._statement())
            except ParseError as error:
                self.errors.syntax(error.message, error.line, error.column)
                self._synchronize()
                if self.pos == start:      # guarantee progress, avoid endless loops
                    self._advance()
        return statements

    def _statement(self) -> Node:
        token = self._peek()
        if token.type == "KEYWORD":
            if token.lexeme == "let":
                return self._var_decl()
            if token.lexeme == "print":
                return self._print_stmt()
            if token.lexeme == "if":
                return self._if_stmt()
            raise self._error("'else' without a matching 'if'.")
        if token.type == "IDENTIFIER":
            return self._assignment()
        raise self._error(f"Unexpected {self._describe(token)}; a statement must start with "
                          "'let', 'print', 'if', or a variable name.")

    def _var_decl(self) -> VariableDeclaration:
        self._advance()  # 'let'
        name = self._expect("IDENTIFIER", "Expected a variable name after 'let'.")
        self._expect("COLON", f"Expected ':' and a type after variable name '{name.lexeme}'.")
        type_token = self._expect("TYPE", "Expected a type (int, float, string or bool) after ':'.")
        self._expect("ASSIGN", "Expected '=' to give the variable an initial value.")
        value = self._expression()
        self._expect_semicolon("variable declaration")
        return VariableDeclaration(name.lexeme, type_token.lexeme, value, name.line, name.column)

    def _assignment(self) -> Assignment:
        name = self._advance()
        self._expect("ASSIGN", f"Expected '=' after '{name.lexeme}' to assign a value.")
        value = self._expression()
        self._expect_semicolon("assignment")
        return Assignment(name.lexeme, value, name.line, name.column)

    def _print_stmt(self) -> PrintStatement:
        keyword = self._advance()
        self._expect("LPAREN", "Expected '(' after 'print'.")
        value = self._expression()
        self._expect("RPAREN", "Expected ')' to close 'print('.")
        self._expect_semicolon("print statement")
        return PrintStatement(value, keyword.line, keyword.column)

    def _if_stmt(self) -> IfStatement:
        keyword = self._advance()
        self._expect("LPAREN", "Expected '(' after 'if'.")
        condition = self._expression()
        self._expect("RPAREN", "Expected ')' after the if condition.")
        then_block = self._block()
        else_block = None
        if self._check_keyword("else"):
            self._advance()
            if self._check_keyword("if"):          # "else if" chain
                nested = self._if_stmt()
                else_block = Block([nested], nested.line, nested.column)
            else:
                else_block = self._block()
        return IfStatement(condition, then_block, else_block, keyword.line, keyword.column)

    def _block(self) -> Block:
        open_brace = self._expect("LBRACE", "Expected '{' to start the block.")
        statements = self._statement_list(in_block=True)
        if not self._check("RBRACE"):
            raise self._error(f"Expected '}}' to close the block opened at line {open_brace.line}.")
        self._advance()
        return Block(statements, open_brace.line, open_brace.column)

    # ----------------------------------------------------------- expressions
    def _expression(self) -> Expression:
        return self._or_expr()

    def _or_expr(self) -> Expression:
        left = self._and_expr()
        while self._check("OR"):
            op = self._advance()
            left = BinaryExpression("or", left, self._and_expr(), op.line, op.column)
        return left

    def _and_expr(self) -> Expression:
        left = self._not_expr()
        while self._check("AND"):
            op = self._advance()
            left = BinaryExpression("and", left, self._not_expr(), op.line, op.column)
        return left

    def _not_expr(self) -> Expression:
        if self._check("NOT"):
            op = self._advance()
            return UnaryExpression("not", self._not_expr(), op.line, op.column)
        return self._comparison()

    def _comparison(self) -> Expression:
        left = self._term()
        while self._peek().type in COMPARISON_TOKENS:
            op = self._advance()
            left = BinaryExpression(op.lexeme, left, self._term(), op.line, op.column)
        return left

    def _term(self) -> Expression:
        left = self._factor()
        while self._peek().type in ("PLUS", "MINUS"):
            op = self._advance()
            left = BinaryExpression(op.lexeme, left, self._factor(), op.line, op.column)
        return left

    def _factor(self) -> Expression:
        left = self._unary()
        while self._peek().type in ("STAR", "SLASH"):
            op = self._advance()
            left = BinaryExpression(op.lexeme, left, self._unary(), op.line, op.column)
        return left

    def _unary(self) -> Expression:
        if self._check("MINUS"):
            op = self._advance()
            return UnaryExpression("-", self._unary(), op.line, op.column)
        return self._primary()

    def _primary(self) -> Expression:
        token = self._peek()
        if token.type == "NUMBER":
            self._advance()
            if "." in token.lexeme:
                return Literal(float(token.lexeme), "float", token.lexeme, token.line, token.column)
            return Literal(int(token.lexeme), "int", token.lexeme, token.line, token.column)
        if token.type == "STRING":
            self._advance()
            return Literal(token.lexeme[1:-1], "string", token.lexeme, token.line, token.column)
        if token.type == "BOOLEAN":
            self._advance()
            return Literal(token.lexeme == "true", "bool", token.lexeme, token.line, token.column)
        if token.type == "IDENTIFIER":
            self._advance()
            return Identifier(token.lexeme, token.line, token.column)
        if token.type == "LPAREN":
            self._advance()
            inner = self._expression()
            self._expect("RPAREN", f"Expected ')' to close the '(' opened at line {token.line}, "
                                   f"column {token.column}.")
            return inner
        raise self._error(f"Expected an expression but found {self._describe(token)}.")
