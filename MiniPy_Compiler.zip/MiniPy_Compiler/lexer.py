"""Lexical analyzer (scanner) for MiniPy.

Turns source text into a list of Token objects using one combined regular
expression. Whitespace and comments are skipped (they never become tokens).
Invalid characters and unterminated strings are reported as lexical errors.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import List

from error_handler import ErrorHandler

KEYWORDS = frozenset({"let", "print", "if", "else"})
TYPE_NAMES = frozenset({"int", "float", "string", "bool"})
BOOLEAN_LITERALS = frozenset({"true", "false"})
WORD_OPERATORS = {"and": "AND", "or": "OR", "not": "NOT"}

# Order matters: longer / more specific patterns must come first.
TOKEN_SPECIFICATION = [
    ("COMMENT", r"//[^\n]*"),
    ("NEWLINE", r"\n"),
    ("WHITESPACE", r"[ \t\r]+"),
    ("NUMBER", r"\d+\.\d+|\d+"),
    ("STRING", r'"[^"\n]*"'),
    ("BAD_STRING", r'"[^"\n]*'),
    ("WORD", r"[A-Za-z_][A-Za-z0-9_]*"),
    ("EQ", r"=="),
    ("NEQ", r"!="),
    ("LE", r"<="),
    ("GE", r">="),
    ("ASSIGN", r"="),
    ("LT", r"<"),
    ("GT", r">"),
    ("PLUS", r"\+"),
    ("MINUS", r"-"),
    ("STAR", r"\*"),
    ("SLASH", r"/"),
    ("LPAREN", r"\("),
    ("RPAREN", r"\)"),
    ("LBRACE", r"\{"),
    ("RBRACE", r"\}"),
    ("COLON", r":"),
    ("SEMICOLON", r";"),
    ("INVALID", r"."),
]
_MASTER_PATTERN = re.compile("|".join(f"(?P<{name}>{pattern})" for name, pattern in TOKEN_SPECIFICATION))


@dataclass(frozen=True)
class Token:
    """A single lexical unit: its category, text, and position (1-based)."""

    type: str
    lexeme: str
    line: int
    column: int

    def __str__(self) -> str:
        return f"{self.type}({self.lexeme!r}) @ {self.line}:{self.column}"


class Lexer:
    """Scans MiniPy source text into tokens."""

    def __init__(self, source: str, errors: ErrorHandler) -> None:
        self.source = source
        self.errors = errors

    def tokenize(self) -> List[Token]:
        """Return all tokens, ending with an EOF token.

        Invalid characters appear as INVALID tokens and are also reported
        to the error handler.
        """
        tokens: List[Token] = []
        line = 1
        line_start = 0
        for match in _MASTER_PATTERN.finditer(self.source):
            kind = match.lastgroup
            text = match.group()
            column = match.start() - line_start + 1
            if kind == "NEWLINE":
                line += 1
                line_start = match.end()
            elif kind in ("WHITESPACE", "COMMENT"):
                continue
            elif kind == "WORD":
                tokens.append(Token(self._classify_word(text), text, line, column))
            elif kind == "BAD_STRING":
                self.errors.lexical("Unterminated string literal: missing closing '\"'.", line, column)
                tokens.append(Token("INVALID", text, line, column))
            elif kind == "INVALID":
                hint = " Did you mean '!='?" if text == "!" else ""
                self.errors.lexical(f"Invalid character {text!r}.{hint}", line, column)
                tokens.append(Token("INVALID", text, line, column))
            else:
                tokens.append(Token(kind, text, line, column))
        tokens.append(Token("EOF", "", line, len(self.source) - line_start + 1))
        return tokens

    @staticmethod
    def _classify_word(word: str) -> str:
        if word in KEYWORDS:
            return "KEYWORD"
        if word in TYPE_NAMES:
            return "TYPE"
        if word in BOOLEAN_LITERALS:
            return "BOOLEAN"
        if word in WORD_OPERATORS:
            return WORD_OPERATORS[word]
        return "IDENTIFIER"


def tokenize(source: str, errors: ErrorHandler | None = None) -> List[Token]:
    """Convenience wrapper used by tests and quick experiments."""
    return Lexer(source, errors if errors is not None else ErrorHandler()).tokenize()
