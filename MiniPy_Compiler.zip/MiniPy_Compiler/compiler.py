"""The compiler pipeline: ties all phases together without any GUI code.

    Source -> Lexer -> Tokens -> Parser -> AST -> Semantic Analyzer
           -> Symbol Table -> Intermediate Code Generator

A phase only runs if the previous one produced no errors.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from ast_nodes import Program
from error_handler import ErrorHandler
from intermediate_code import CodeGenerator
from lexer import Lexer, Token
from parser import Parser
from semantic_analyzer import SemanticAnalyzer
from symbol_table import SymbolTable

PHASES = ("Lexical analysis", "Syntax analysis", "Semantic analysis", "Code generation")


@dataclass
class CompilationResult:
    source: str
    errors: ErrorHandler
    tokens: List[Token] = field(default_factory=list)
    program: Optional[Program] = None          # None if parsing failed
    symbols: Optional[SymbolTable] = None      # None if semantic analysis never ran
    code: List[str] = field(default_factory=list)
    phase_status: Dict[str, str] = field(default_factory=dict)   # OK / FAILED / SKIPPED

    @property
    def success(self) -> bool:
        return not self.errors.has_errors()


def compile_source(source: str) -> CompilationResult:
    """Run every phase on `source` and return everything that was produced."""
    errors = ErrorHandler()
    result = CompilationResult(source=source, errors=errors,
                               phase_status={name: "SKIPPED" for name in PHASES})

    result.tokens = Lexer(source, errors).tokenize()
    result.phase_status["Lexical analysis"] = "FAILED" if errors.has_errors() else "OK"
    if errors.has_errors():
        return result

    program = Parser(result.tokens, errors).parse()
    result.phase_status["Syntax analysis"] = "FAILED" if errors.has_errors() else "OK"
    if errors.has_errors():
        return result
    result.program = program

    result.symbols = SemanticAnalyzer(errors).analyze(program)
    result.phase_status["Semantic analysis"] = "FAILED" if errors.has_errors() else "OK"
    if errors.has_errors():
        return result

    result.code = CodeGenerator().generate(program)
    result.phase_status["Code generation"] = "OK"
    return result
