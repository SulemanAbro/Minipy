"""Unit tests for intermediate code generation and the full pipeline (Phase 4)."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from compiler import compile_source


def code_of(source):
    result = compile_source(source)
    assert result.success, [str(e) for e in result.errors.errors]
    return result.code


class CodeGenTests(unittest.TestCase):
    def test_precedence_example_from_specification(self):
        code = code_of("let a: int = 1; let b: int = 2; let c: int = 3; let result: int = a + b * c; print(result);")
        self.assertEqual(code, ["a = 1", "b = 2", "c = 3", "t1 = b * c", "t2 = a + t1", "result = t2",
                                "print result"])

    def test_parentheses_change_generated_order(self):
        code = code_of("let a: int = 1; let b: int = 2; let c: int = 3; let r: int = (a + b) * c; print(r);")
        self.assertEqual(code[3:6], ["t1 = a + b", "t2 = t1 * c", "r = t2"])

    def test_assignment_and_unary(self):
        code = code_of("let a: int = 4; a = -a; print(a);")
        self.assertEqual(code, ["a = 4", "t1 = -a", "a = t1", "print a"])

    def test_boolean_and_comparison(self):
        code = code_of("let a: int = 1; let ok: bool = a > 0 and not (a == 5); print(ok);")
        self.assertEqual(code[1:], ["t1 = a > 0", "t2 = a == 5", "t3 = not t2", "t4 = t1 and t3",
                                    "ok = t4", "print ok"])

    def test_if_without_else(self):
        code = code_of("let age: int = 20; if (age > 18) { print(age); }")
        self.assertEqual(code, ["age = 20", "t1 = age > 18", "ifFalse t1 goto L1", "print age", "L1:"])

    def test_if_with_else(self):
        code = code_of("let x: int = 1; if (x > 0) { print(x); } else { print(0); }")
        self.assertEqual(code[1:], ["t1 = x > 0", "ifFalse t1 goto L1", "print x", "goto L2", "L1:",
                                    "print 0", "L2:"])

    def test_nested_if_uses_unique_labels(self):
        code = code_of("let x: int = 1; if (x > 0) { if (x > 5) { print(x); } }")
        labels = [line for line in code if line.endswith(":")]
        self.assertEqual(labels, ["L2:", "L1:"])

    def test_example_files_compile_as_expected(self):
        base = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "examples")
        with open(os.path.join(base, "valid_program.mpy"), encoding="utf-8") as f:
            self.assertTrue(compile_source(f.read()).success)
        for name in ("invalid_program.mpy", "syntax_error.mpy"):
            with open(os.path.join(base, name), encoding="utf-8") as f:
                self.assertFalse(compile_source(f.read()).success)


class PipelineTests(unittest.TestCase):
    def assertNoCode(self, source, failed_phase):
        result = compile_source(source)
        self.assertFalse(result.success)
        self.assertEqual(result.code, [])
        self.assertEqual(result.phase_status[failed_phase], "FAILED")
        self.assertEqual(result.phase_status["Code generation"], "SKIPPED")

    def test_lexical_error_stops_pipeline(self):
        self.assertNoCode("let a: int = 1 $ 2;", "Lexical analysis")

    def test_syntax_error_stops_pipeline(self):
        self.assertNoCode("let a: int = 1", "Syntax analysis")

    def test_semantic_error_stops_pipeline(self):
        self.assertNoCode("print(nope);", "Semantic analysis")

    def test_empty_and_whitespace_input(self):
        for source in ("", "   \n\t\n", "// just a comment"):
            self.assertNoCode(source, "Syntax analysis")

    def test_malformed_input_never_crashes(self):
        for source in ["let", "((((", "}{", "let 1: int = 2;", "print(", "\"", "@#$", "if (x) {", "let a: int = ;"]:
            result = compile_source(source)
            self.assertFalse(result.success, source)
            self.assertEqual(result.code, [], source)

    def test_errors_are_categorised_with_positions(self):
        result = compile_source("let a: int = 1;\nlet b: int = @;")
        error = result.errors.errors[0]
        self.assertEqual((error.category, error.line, error.column), ("Lexical Error", 2, 14))
        self.assertEqual(str(error), "Lexical Error at line 2, column 14: Invalid character '@'.")


if __name__ == "__main__":
    unittest.main()
