"""Unit tests for the lexer (Phase 1)."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from error_handler import ErrorHandler
from lexer import tokenize


def types(source):
    return [t.type for t in tokenize(source)][:-1]   # drop EOF


class LexerTests(unittest.TestCase):
    def test_declaration_tokens(self):
        self.assertEqual(types("let total: int = price + 25;"),
                         ["KEYWORD", "IDENTIFIER", "COLON", "TYPE", "ASSIGN", "IDENTIFIER",
                          "PLUS", "NUMBER", "SEMICOLON"])

    def test_all_operators_and_delimiters(self):
        self.assertEqual(types("== != < > <= >= = + - * / ( ) { } : ;"),
                         ["EQ", "NEQ", "LT", "GT", "LE", "GE", "ASSIGN", "PLUS", "MINUS", "STAR",
                          "SLASH", "LPAREN", "RPAREN", "LBRACE", "RBRACE", "COLON", "SEMICOLON"])

    def test_word_operators_booleans_keywords(self):
        self.assertEqual(types("and or not true false if else print"),
                         ["AND", "OR", "NOT", "BOOLEAN", "BOOLEAN", "KEYWORD", "KEYWORD", "KEYWORD"])

    def test_numbers_and_strings(self):
        tokens = tokenize('12 3.14 "hi there"')
        self.assertEqual([(t.type, t.lexeme) for t in tokens[:-1]],
                         [("NUMBER", "12"), ("NUMBER", "3.14"), ("STRING", '"hi there"')])

    def test_comments_and_whitespace_are_not_tokens(self):
        self.assertEqual(types("// only a comment\n   \t x // trailing\n"), ["IDENTIFIER"])

    def test_line_and_column_numbers(self):
        tokens = tokenize("let a: int = 1;\n  print(a);")
        print_token = [t for t in tokens if t.lexeme == "print"][0]
        self.assertEqual((print_token.line, print_token.column), (2, 3))
        self.assertEqual((tokens[1].line, tokens[1].column), (1, 5))

    def test_invalid_character_is_reported(self):
        errors = ErrorHandler()
        tokenize("let x: int = 5 @ 3;", errors)
        self.assertEqual(len(errors.errors), 1)
        self.assertEqual(errors.errors[0].category, "Lexical Error")
        self.assertEqual((errors.errors[0].line, errors.errors[0].column), (1, 16))

    def test_lone_bang_hint(self):
        errors = ErrorHandler()
        tokenize("a ! b", errors)
        self.assertIn("!=", errors.errors[0].message)

    def test_unterminated_string(self):
        errors = ErrorHandler()
        tokenize('let s: string = "oops;', errors)
        self.assertTrue(errors.has_category("Lexical Error"))
        self.assertIn("Unterminated", errors.errors[0].message)

    def test_empty_source_gives_only_eof(self):
        self.assertEqual([t.type for t in tokenize("")], ["EOF"])


if __name__ == "__main__":
    unittest.main()
