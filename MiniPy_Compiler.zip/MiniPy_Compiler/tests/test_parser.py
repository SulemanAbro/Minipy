"""Unit tests for the parser and AST (Phase 2)."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ast_nodes import (Assignment, BinaryExpression, IfStatement, Literal, PrintStatement,
                       UnaryExpression, VariableDeclaration, format_tree)
from error_handler import ErrorHandler
from lexer import tokenize
from parser import Parser


def parse(source):
    errors = ErrorHandler()
    program = Parser(tokenize(source, errors), errors).parse()
    return program, errors


def show(node):
    """Fully parenthesised text of an expression, to check tree shape."""
    if isinstance(node, BinaryExpression):
        return f"({show(node.left)} {node.operator} {show(node.right)})"
    if isinstance(node, UnaryExpression):
        return f"({node.operator} {show(node.operand)})"
    return getattr(node, "name", None) or node.raw


def expr_of(source_expr):
    program, errors = parse(f"let r: int = {source_expr};")
    assert not errors.has_errors(), [str(e) for e in errors.errors]
    return show(program.statements[0].initializer)


class ParserTests(unittest.TestCase):
    def test_statement_node_types(self):
        program, errors = parse('let a: int = 1; a = 2; print(a); if (true) { print(a); }')
        self.assertFalse(errors.has_errors())
        kinds = [type(s) for s in program.statements]
        self.assertEqual(kinds, [VariableDeclaration, Assignment, PrintStatement, IfStatement])

    def test_multiplication_binds_tighter_than_addition(self):
        self.assertEqual(expr_of("a + b * c"), "(a + (b * c))")
        self.assertEqual(expr_of("a * b + c"), "((a * b) + c)")

    def test_left_associativity(self):
        self.assertEqual(expr_of("a - b - c"), "((a - b) - c)")
        self.assertEqual(expr_of("a / b * c"), "((a / b) * c)")

    def test_parentheses_override_precedence(self):
        self.assertEqual(expr_of("(a + b) * c"), "((a + b) * c)")

    def test_boolean_precedence(self):
        self.assertEqual(expr_of("a or b and c"), "(a or (b and c))")
        self.assertEqual(expr_of("not a and b"), "((not a) and b)")
        self.assertEqual(expr_of("a + 1 < b * 2 and c"), "(((a + 1) < (b * 2)) and c)")

    def test_unary_minus(self):
        self.assertEqual(expr_of("-a * b"), "((- a) * b)")

    def test_literal_values(self):
        program, _ = parse('let a: float = 2.5; let b: string = "x"; let c: bool = true;')
        values = [s.initializer for s in program.statements]
        self.assertEqual([(v.value, v.type_name) for v in values],
                         [(2.5, "float"), ("x", "string"), (True, "bool")])

    def test_else_if_chain(self):
        program, errors = parse("if (a) { print(1); } else if (b) { print(2); } else { print(3); }")
        self.assertFalse(errors.has_errors())
        self.assertIsInstance(program.statements[0].else_block.statements[0], IfStatement)

    def test_missing_semicolon(self):
        _, errors = parse("let x: int = 5\nprint(x);")
        self.assertEqual(len(errors.errors), 1)
        error = errors.errors[0]
        self.assertEqual(error.category, "Syntax Error")
        self.assertEqual((error.line, error.column), (1, 15))
        self.assertIn("Expected ';' after variable declaration", error.message)

    def test_unmatched_open_parenthesis(self):
        _, errors = parse("let x: int = (1 + 2;")
        self.assertIn("Expected ')'", errors.errors[0].message)

    def test_unmatched_close_parenthesis(self):
        _, errors = parse("let x: int = (1 + 2));")
        self.assertIn("Unmatched ')'", errors.errors[0].message)

    def test_missing_closing_brace(self):
        _, errors = parse("if (true) { print(1);")
        self.assertIn("Expected '}'", errors.errors[0].message)

    def test_stray_closing_brace(self):
        _, errors = parse("print(1); }")
        self.assertIn("Unmatched '}'", errors.errors[0].message)

    def test_malformed_expression(self):
        _, errors = parse("let x: int = * 3;")
        self.assertIn("Expected an expression", errors.errors[0].message)

    def test_missing_type(self):
        _, errors = parse("let x = 3;")
        self.assertTrue(any("':'" in e.message for e in errors.errors))

    def test_error_recovery_reports_several_errors(self):
        _, errors = parse("let a: int = 1\nlet b: int = 2\nprint(a);")
        self.assertEqual(len(errors.errors), 2)

    def test_empty_program_is_an_error(self):
        _, errors = parse("   \n// nothing here\n")
        self.assertIn("empty", errors.errors[0].message)

    def test_garbage_does_not_crash_or_loop(self):
        for source in ["}}}", ")))", "let", "if", "if (", "else", "= = =", "let x: int = ;;;", "{"]:
            _, errors = parse(source)
            self.assertTrue(errors.has_errors(), source)

    def test_tree_text_contains_node_names(self):
        program, _ = parse("let a: int = 1 + 2;")
        text = format_tree(program)
        self.assertIn("VariableDeclaration a: int", text)
        self.assertIn("BinaryExpression '+'", text)


if __name__ == "__main__":
    unittest.main()
