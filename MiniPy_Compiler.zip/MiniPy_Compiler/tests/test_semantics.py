"""Unit tests for the semantic analyzer and symbol table (Phase 3)."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from compiler import compile_source
from symbol_table import SymbolTable


def errors_of(source):
    return [str(e) for e in compile_source(source).errors.errors]


class SemanticTests(unittest.TestCase):
    def assertOneError(self, source, fragment):
        errors = errors_of(source)
        self.assertEqual(len(errors), 1, errors)
        self.assertIn(fragment, errors[0])
        self.assertIn("Semantic Error at line", errors[0])

    def test_valid_program_has_no_errors(self):
        self.assertEqual(errors_of("let a: int = 1; let b: float = a + 2.5; print(b);"), [])

    def test_undeclared_variable_use(self):
        self.assertOneError("print(x);", "'x' is used but was never declared")

    def test_assignment_to_undeclared_variable(self):
        self.assertOneError("y = 3;", "Cannot assign to 'y'")

    def test_duplicate_declaration(self):
        self.assertOneError("let a: int = 1; let a: int = 2; print(a);", "already declared")

    def test_duplicate_does_not_overwrite_original(self):
        result = compile_source("let a: int = 1; let a: string = \"s\"; print(a);")
        self.assertEqual([s.type_name for s in result.symbols.all_symbols()], ["int"])

    def test_type_mismatch_in_declaration(self):
        self.assertOneError('let a: int = "text"; print(a);', "cannot store a string value in int")

    def test_type_mismatch_in_assignment(self):
        self.assertOneError("let a: int = 1; a = true; print(a);", "cannot store a bool value in int")

    def test_int_widens_to_float_but_not_back(self):
        self.assertEqual(errors_of("let f: float = 1; print(f);"), [])
        self.assertOneError("let f: float = 1.5; let i: int = f; print(i);", "cannot store a float value in int")

    def test_division_always_gives_float(self):
        self.assertOneError("let a: int = 4; let b: int = a / 2; print(b);", "float value in int")
        self.assertEqual(errors_of("let a: int = 4; let b: float = a / 2; print(b);"), [])

    def test_division_by_literal_zero(self):
        self.assertOneError("let a: float = 4 / 0; print(a);", "Division by zero")

    def test_invalid_operations_between_types(self):
        self.assertOneError('let s: string = "a" + 1; print(s);', "Operator '+' cannot be applied to string and int")
        self.assertOneError('let s: int = "a" * 2; print(s);', "Operator '*'")
        self.assertOneError("let b: bool = 1 and true; print(b);", "needs bool operands")
        self.assertOneError('let b: bool = "a" < "b"; print(b);', "needs numeric operands")
        self.assertOneError('let b: bool = 1 == "a"; print(b);', "Cannot compare int with string")
        self.assertOneError("let b: bool = not 3; print(b);", "'not' needs a bool")

    def test_string_concatenation_is_allowed(self):
        self.assertEqual(errors_of('let s: string = "a" + "b"; print(s);'), [])

    def test_condition_must_be_bool(self):
        self.assertOneError("let a: int = 1; if (a) { print(a); }", "condition of 'if' must be bool")

    def test_variable_declared_in_block_is_not_visible_outside(self):
        self.assertOneError("if (true) { let a: int = 1; print(a); } print(a);", "'a' is used but was never declared")

    def test_shadowing_in_inner_scope_is_allowed(self):
        self.assertEqual(errors_of("let a: int = 1; if (true) { let a: int = 2; print(a); } print(a);"), [])

    def test_initializer_cannot_use_variable_being_declared(self):
        self.assertOneError("let a: int = a + 1; print(a);", "'a' is used but was never declared")

    def test_unused_variable_is_only_a_warning(self):
        result = compile_source("let a: int = 1;")
        self.assertTrue(result.success)
        self.assertEqual(len(result.errors.warnings), 1)
        self.assertIn("never used", result.errors.warnings[0].message)

    def test_symbol_table_contents(self):
        result = compile_source('let a: int = 5; let s: string = "hi"; if (true) { let b: float = 1; print(b); } print(a); print(s);')
        rows = result.symbols.rows()
        self.assertEqual(rows[0], ("a", "int", "global", 1, "5", "yes"))
        self.assertEqual(rows[1], ("s", "string", "global", 1, '"hi"', "yes"))
        self.assertEqual(rows[2], ("b", "float", "if (line 1)", 1, "1.0", "yes"))

    def test_symbol_table_scopes_directly(self):
        table = SymbolTable()
        self.assertIsNotNone(table.declare("x", "int", 1, 1))
        self.assertIsNone(table.declare("x", "float", 2, 1))
        table.enter_scope("inner")
        self.assertIsNotNone(table.declare("x", "bool", 3, 1))
        self.assertEqual(table.lookup("x").type_name, "bool")
        table.exit_scope()
        self.assertEqual(table.lookup("x").type_name, "int")
        with self.assertRaises(RuntimeError):
            table.exit_scope()


if __name__ == "__main__":
    unittest.main()
