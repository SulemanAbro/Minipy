# MiniPy — A Mini Compiler with Error Detection and Intermediate Code Generation

A Compiler Construction semester project (BS Computer Science, Semester 5).
MiniPy reads programs written in a small custom language, checks them, and shows the result of every compiler phase in a Tkinter desktop application. All results are produced by the real compiler modules — nothing is hard-coded.

![MiniPy GUI – successful compilation](docs/screenshots/gui_success.png)
![MiniPy GUI – errors highlighted](docs/screenshots/gui_errors.png)

## 1. Problem statement
Students learn compiler theory (lexing, parsing, type checking, intermediate code) but rarely see all phases working together. This project builds a complete, understandable compiler **front end** for a small language and makes each phase visible.

## 2. Objectives
* Design a small language (MiniPy) with a clear grammar.
* Implement lexical analysis, recursive-descent parsing, AST construction, semantic analysis, a scoped symbol table and three-address-code generation.
* Detect and report lexical, syntax and semantic errors with line and column numbers, without crashing.
* Provide a GUI that displays the output of every phase, and automated tests that run without the GUI.

## 3. Features
* Types `int`, `float`, `string`, `bool`; `let` declarations; assignment; `print`; `if / else if / else`
* Arithmetic `+ - * /`, comparison `== != < > <= >=`, boolean `and or not`, unary minus, parentheses, `//` comments
* Correct precedence and left-associativity
* Multiple syntax errors per run (panic-mode recovery)
* Scoped symbol table (global + one scope per `if`/`else` block) with shadowing
* Warnings for unused variables
* Dark-theme GUI: line numbers, syntax colouring, error underlining, double-click an error to jump to it, tabs for Tokens / AST / Symbol Table / Intermediate Code / Errors, status bar
* Command-line mode: `python main.py --cli examples/valid_program.mpy`
* 62 automated `unittest` tests

## 4. Compiler phases
| # | Phase | File | Input → Output |
|---|-------|------|----------------|
| 1 | Lexical analysis | `lexer.py` | source text → tokens |
| 2 | Syntax analysis | `parser.py` | tokens → AST (`ast_nodes.py`) |
| 3 | Semantic analysis | `semantic_analyzer.py` | AST → checked AST + symbol table |
| 4 | Symbol table | `symbol_table.py` | scoped storage of declared variables |
| 5 | Intermediate code | `intermediate_code.py` | AST → three-address code |
| 6 | Error handling | `error_handler.py` | collects categorised errors from all phases |

A phase runs only if the previous phase had no errors, so invalid programs never reach code generation.

## 5. Architecture
```mermaid
flowchart LR
    SRC[Source code] --> LEX[Lexer<br/>lexer.py]
    LEX -->|tokens| PAR[Parser<br/>parser.py]
    PAR -->|AST| SEM[Semantic Analyzer<br/>semantic_analyzer.py]
    SEM <--> SYM[(Symbol Table<br/>symbol_table.py)]
    SEM -->|checked AST| GEN[Intermediate Code Generator<br/>intermediate_code.py]
    GEN -->|three-address code| OUT[Results]
    LEX -.errors.-> ERR[ErrorHandler<br/>error_handler.py]
    PAR -.errors.-> ERR
    SEM -.errors/warnings.-> ERR
    PIPE[compiler.py<br/>compile_source] --- LEX
    GUI[GUI<br/>gui.py] -->|calls| PIPE
    OUT --> GUI
    ERR --> GUI
```

## 6. Project structure
```
MiniPy_Compiler/
├── main.py                 start the program (GUI or --cli)
├── gui.py                  Tkinter interface (no compiler logic)
├── compiler.py             runs all phases in order -> CompilationResult
├── lexer.py                Phase 1: tokens
├── parser.py               Phase 2: recursive-descent parser
├── ast_nodes.py            AST node classes + tree printer
├── semantic_analyzer.py    Phase 3: scope and type checking
├── symbol_table.py         scoped symbol table
├── intermediate_code.py    Phase 4: three-address code
├── error_handler.py        error categories and collection
├── tests/                  test_lexer / test_parser / test_semantics / test_codegen
├── examples/               valid_program.mpy, invalid_program.mpy, syntax_error.mpy
├── docs/                   DEMO_SCRIPT.md, VIVA_QUESTIONS.md, screenshots
├── README.md
└── requirements.txt
```

### What each file does (simple English)
* **main.py** – the door into the program. With no options it opens the window; with `--cli file.mpy` it compiles in the terminal.
* **gui.py** – draws the window, buttons, editor and tabs. When you press Compile it hands your text to `compiler.py` and shows what comes back. It does no compiling itself.
* **compiler.py** – the "manager". It calls lexer → parser → semantic analyzer → code generator in order, and stops at the first phase that fails. It returns one `CompilationResult` object holding everything.
* **lexer.py** – reads the text character by character (using a regular expression) and cuts it into tokens such as `KEYWORD`, `IDENTIFIER`, `NUMBER`. Skips spaces and comments; reports bad characters.
* **parser.py** – checks that tokens follow the grammar and builds the AST. One method per grammar rule; it reports syntax errors with line and column.
* **ast_nodes.py** – the building blocks of the tree (`Program`, `BinaryExpression`, `IfStatement` …) plus `format_tree()` which draws the tree as text.
* **semantic_analyzer.py** – walks the AST and checks the *meaning*: is the variable declared, are the types compatible, is the `if` condition a bool?
* **symbol_table.py** – the notebook of variables: name, type, scope, line, value. Handles nested scopes and refuses to overwrite duplicates.
* **intermediate_code.py** – walks the checked AST and writes simple three-address instructions with temporaries (`t1`, `t2`) and labels (`L1`).
* **error_handler.py** – a shared inbox where every phase drops its errors (category, message, line, column).
* **tests/** – automatic checks that each phase behaves correctly, runnable without the GUI.
* **examples/** – sample MiniPy programs that compile or fail on purpose.

## 7. Installation
1. Install **Python 3.10 or newer** from python.org (Windows installer includes Tkinter; tick *tcl/tk and IDLE*). *(Python 3.9 and older have a built-in module also called `parser`, which can clash with our `parser.py`.)*
2. Copy the `MiniPy_Compiler` folder anywhere.
3. No packages to install — see `requirements.txt` (standard library only).

Linux only: `sudo apt install python3-tk`.

## 8. Running
```
cd MiniPy_Compiler
python main.py                       # GUI
python main.py examples/valid_program.mpy        # GUI with a file loaded
python main.py --cli examples/valid_program.mpy  # terminal output
```
Works from VS Code, PyCharm or any terminal (run from the project folder). Shortcuts: **F5 / Ctrl+Enter** compile, **Ctrl+O** open, **Ctrl+S** save.

## 9. The MiniPy language

### Example
```
let price: int = 40;
let name: string = "Ali";
let ok: bool = price > 18 and not (price == 0);
price = price + 1;      // comment
if (ok) { print(price); } else { print(name); }
```

### Lexical rules
`KEYWORD` (let print if else) · `TYPE` (int float string bool) · `BOOLEAN` (true false) · `AND OR NOT` · `IDENTIFIER` `[A-Za-z_][A-Za-z0-9_]*` · `NUMBER` (`12`, `3.14`) · `STRING` (`"text"`, one line) · operators `PLUS MINUS STAR SLASH EQ NEQ LT GT LE GE ASSIGN` · `LPAREN RPAREN LBRACE RBRACE COLON SEMICOLON`. Whitespace and `//` comments are discarded.

### Grammar (EBNF)
```
program     = { statement } EOF
statement   = var_decl | assignment | print_stmt | if_stmt
var_decl    = "let" IDENT ":" TYPE "=" expr ";"
assignment  = IDENT "=" expr ";"
print_stmt  = "print" "(" expr ")" ";"
if_stmt     = "if" "(" expr ")" block [ "else" ( block | if_stmt ) ]
block       = "{" { statement } "}"

expr        = or_expr
or_expr     = and_expr { "or" and_expr }
and_expr    = not_expr { "and" not_expr }
not_expr    = "not" not_expr | comparison
comparison  = term { ("==" | "!=" | "<" | ">" | "<=" | ">=") term }
term        = factor { ("+" | "-") factor }
factor      = unary { ("*" | "/") unary }
unary       = "-" unary | primary
primary     = NUMBER | STRING | BOOLEAN | IDENT | "(" expr ")"
```
Precedence, highest first: parentheses · unary `-` · `* /` · `+ -` · comparisons · `not` · `and` · `or`.

### Type rules
| Operation | Allowed operand types | Result |
|-----------|----------------------|--------|
| `+ - *` | int/float (mixed OK) | int if both int, else float |
| `+` | string, string | string |
| `/` | int/float | **always float**; dividing by literal `0` is an error |
| `== !=` | both numeric, or same type | bool |
| `< > <= >=` | numeric | bool |
| `and or not` | bool | bool |
| unary `-` | int/float | same type |
| assignment | same type; `int` may go into `float` | — |
| `if` condition | must be bool | — |

There are no other implicit conversions. Variables must be declared with `let` before use; the same name cannot be declared twice in one scope, but an inner block may shadow an outer variable.

## 10. Sample compiler output
Input:
```
let a: int = 2;
let b: int = 3;
let c: int = 4;
let result: int = a + b * c;
print(result);
if (result > 10) {
    print(a);
}
```
**Tokens (first 12 of 51):**
```
1:1   KEYWORD    'let'
1:5   IDENTIFIER 'a'
1:6   COLON      ':'
1:8   TYPE       'int'
1:12  ASSIGN     '='
1:14  NUMBER     '2'
1:15  SEMICOLON  ';'
2:1   KEYWORD    'let'
2:5   IDENTIFIER 'b'
2:6   COLON      ':'
2:8   TYPE       'int'
2:12  ASSIGN     '='
```
**AST:**
```
Program
├── VariableDeclaration a: int
│   └── value: Literal 2 (int)
├── VariableDeclaration b: int
│   └── value: Literal 3 (int)
├── VariableDeclaration c: int
│   └── value: Literal 4 (int)
├── VariableDeclaration result: int
│   └── value: BinaryExpression '+'  [type: int]
│       ├── left: Identifier a  [type: int]
│       └── right: BinaryExpression '*'  [type: int]
│           ├── left: Identifier b  [type: int]
│           └── right: Identifier c  [type: int]
├── PrintStatement
│   └── value: Identifier result  [type: int]
└── IfStatement
    ├── condition: BinaryExpression '>'  [type: bool]
    │   ├── left: Identifier result  [type: int]
    │   └── right: Literal 10 (int)
    └── then: Block
        └── PrintStatement
            └── value: Identifier a  [type: int]
```
**Symbol table:**
```
Name    Type  Scope   Line  Initial  Used
a       int   global  1     2        yes
b       int   global  2     3        yes
c       int   global  3     4        yes
result  int   global  4     -        yes
```
**Intermediate code:**
```
a = 2
b = 3
c = 4
t1 = b * c
t2 = a + t1
result = t2
print result
t3 = result > 10
ifFalse t3 goto L1
print a
L1:
```
**Error example** (`examples/invalid_program.mpy`):
```
Semantic Error at line 3, column 5: Variable 'age' is already declared in this scope (first declared at line 2).
Warning at line 4, column 5: Variable 'name' is declared but never used.
Semantic Error at line 4, column 20: Type mismatch: cannot store an int value in string variable 'name'.
Semantic Error at line 5, column 1: Cannot assign to 'total' because it was never declared. Declare it first: let total: <type> = <value>;
Semantic Error at line 6, column 7: Variable 'missing' is used but was never declared.
Warning at line 7, column 5: Variable 'ratio' is declared but never used.
Semantic Error at line 7, column 18: Type mismatch: cannot store a float value in int variable 'ratio'. MiniPy does not convert floats to int automatically (note: '/' always gives a float).
Semantic Error at line 8, column 5: The condition of 'if' must be bool, but it is int. Hint: use a comparison such as x > 0.
Semantic Error at line 9, column 15: Operator '+' cannot be applied to int and string. MiniPy never converts types automatically.
```
**Syntax-error example** (`examples/syntax_error.mpy`):
```
Syntax Error at line 2, column 15: Expected ';' after variable declaration.
Syntax Error at line 3, column 20: Expected ')' to close the '(' opened at line 3, column 14.
Syntax Error at line 4, column 8: Expected ')' to close 'print('.
Syntax Error at line 5, column 11: Expected ')' after the if condition.
Syntax Error at line 7, column 1: Unmatched '}': there is no open block to close.
```

## 11. Testing
```
python -m unittest discover -s tests -v
```
| File | Covers |
|------|--------|
| `test_lexer.py` | token recognition, positions, invalid characters, unterminated strings, empty input |
| `test_parser.py` | precedence, associativity, parentheses, missing `;`, unmatched `(` `)` `{` `}`, error recovery, malformed/garbage input |
| `test_semantics.py` | undeclared variables, duplicates, type mismatches, scopes, symbol-table contents, warnings |
| `test_codegen.py` | exact three-address code, labels for `if`/`else`, invalid programs never reach code generation, empty input |

## 12. Limitations
* Only a small subset of language features: no loops, functions, arrays, input or user-defined types.
* Output is **intermediate code only** — no machine code or executable is produced.
* No short-circuit evaluation: `and`/`or` are computed as ordinary operations in the TAC.
* Variables with the same name in different scopes keep the same name in the TAC.
* Lexical errors stop compilation before parsing; syntax errors stop it before semantic analysis (so only one kind of error is shown per run).
* Only division by the *literal* `0` is detected; values are not computed at compile time.

## 13. Future enhancements
`while` loops, functions, arrays, constant folding and other optimisations, a TAC interpreter to actually run programs, renaming variables per scope, short-circuit jumps, a back end producing assembly/bytecode, syntax-error suggestions, and saving/loading projects with tabs.

## 14. Team division
| Student 1 | Student 2 |
|-----------|-----------|
| Grammar, `lexer.py`, `parser.py`, `ast_nodes.py`, `semantic_analyzer.py` | `gui.py`, symbol-table display, `intermediate_code.py` integration, tests interface, documentation & presentation |

Both students should be able to explain the whole pipeline — see `docs/VIVA_QUESTIONS.md` and `docs/DEMO_SCRIPT.md`.
